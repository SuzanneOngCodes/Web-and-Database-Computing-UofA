% Extension 2 - Determine the difficulty of the game through user's input

clc

% Easy

% This program allows the user to input a guess of the location of the treasure
% It only allows numbers that are between 1 and 5 (inclusive)
n=input("Please enter a number between 1 and 5: ");
m=input("Please enter another number between 1 and 5: ");

% Stores the user's numbers into a vector named "User"
User=[n,m];

% Displays the error message if the numbers are less than 1 or more than 5
if n<1||n>5||m<1||m>5 
    
    fprintf("Invalid! Try again!\n\n");
    
% Displays the error message if the numbers are less than 1 and more than 5
elseif n<1||n>5&&m<1||m>5
    
    fprintf("Invalid! Try again!\n\n");
                
% Displays the location of the user and a message that informs the user that they are very close to the location of the treasure
elseif abs(n-X)==0 && abs(m-Y)==1 || abs(m-Y)==0 && abs(n-X)==1
    
    % Prints the message and the user's input 
    fprintf("Your current location is :");
    disp(User);
    fprintf("You're almost there!\n\n");
    
% Displays the location of the user and a message that informs the user that they are close to the location of the treasure
elseif abs(n-X)<=2 && abs(m-Y)<=2
    
    % Prints the message and the user's input 
    fprintf("Your current location is :");
    disp(User);
    fprintf("You�re getting closer...\n\n");

% Displays the location of the user and a message that informs the user that they are far from the location of the treasure        
else
    
    % Prints the message and the user's input
    fprintf("Your current location is :");
    disp(User);
    fprintf("You�re far, far away from the treasure...\n\n");

end

% Hard

% This program allows the user to input a guess of the location of the treasure
% It only allows numbers that are between 1 and 10 (inclusive)
n=input("Please enter a number between 1 and 10: ");
m=input("Please enter another number between 1 and 10: ");

% Stores the user's numbers into a vector named "User"
User=[n,m];

% Displays the error message if the numbers are less than 1 or more than 10
if n<1||n>10||m<1||m>10 
    
    fprintf("Invalid! Try again!\n\n");
    
% Displays the error message if the numbers are less than 1 and more than
% 10
elseif n<1||n>10&&m<1||m>10
    
    fprintf("Invalid! Try again!\n\n");
                
% Displays the location of the user and a message that informs the user that they are very close to the location of the treasure
elseif abs(n-X)==0 && abs(m-Y)==1 || abs(m-Y)==0 && abs(n-X)==1
    
    % Prints the message and the user's input 
    fprintf("Your current location is :");
    disp(User);
    fprintf("You're almost there!\n\n");
    
% Displays the location of the user and a message that informs the user that they are close to the location of the treasure
elseif abs(n-X)<=2 && abs(m-Y)<=2
    
    % Prints the message and the user's input 
    fprintf("Your current location is :");
    disp(User);
    fprintf("You�re getting closer...\n\n");

% Displays the location of the user and a message that informs the user that they are far from the location of the treasure        
else
    
    % Prints the message and the user's input
    fprintf("Your current location is :");
    disp(User);
    fprintf("You�re far, far away from the treasure...\n\n");

end

% Depressing

% This program allows the user to input a guess of the location of the treasure
% It only allows numbers that are between 1 and 15 (inclusive)
n=input("Please enter a number between 1 and 15: ");
m=input("Please enter another number between 1 and 15: ");

% Stores the user's numbers into a vector named "User"
User=[n,m];

% Displays the error message if the numbers are less than 1 or more than 15
if n<1||n>15||m<1||m>15 
    
    fprintf("Invalid! Try again!\n\n");
    
% Displays the error message if the numbers are less than 1 and more than 15
elseif n<1||n>15&&m<1||m>15
    
    fprintf("Invalid! Try again!\n\n");
                
% Displays the location of the user and a message that informs the user that they are very close to the location of the treasure
elseif abs(n-X)==0 && abs(m-Y)==1 || abs(m-Y)==0 && abs(n-X)==1
    
    % Prints the message and the user's input 
    fprintf("Your current location is :");
    disp(User);
    fprintf("You're almost there!\n\n");
    
% Displays the location of the user and a message that informs the user that they are close to the location of the treasure
elseif abs(n-X)<=2 && abs(m-Y)<=2
    
    % Prints the message and the user's input 
    fprintf("Your current location is :");
    disp(User);
    fprintf("You�re getting closer...\n\n");

% Displays the location of the user and a message that informs the user that they are far from the location of the treasure        
else
    
    % Prints the message and the user's input
    fprintf("Your current location is :");
    disp(User);
    fprintf("You�re far, far away from the treasure...\n\n");

end