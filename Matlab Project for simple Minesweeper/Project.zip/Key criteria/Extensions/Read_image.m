% Extension 4 - Displays an image in the program from a .jpeg file

clc

% This program loads the image which is copied directly from an online search engine
imageData=imread('TreasureBoxImage.jpeg');

% Display the .jpeg file in MATLAB as an image
imshow(imageData);
