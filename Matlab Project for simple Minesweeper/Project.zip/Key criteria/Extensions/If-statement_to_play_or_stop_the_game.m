% Extension 1- Determine whether the user decide to play or not from their input 'Yes' or 'No'. 

clc

% Asks the user whether or not they want to play this game
decision=input("Do you want to play a game? Please enter Yes or No only : ","s");

% This while loop compares the answer entered by the user with the variable "decision"
% It will start the game when the user entered "Yes", stop the game if the user entered "No" and demands another input if the user did not follow the instructions to enter 'Yes' or 'No' only
while strcmp(decision, "Yes")==0 && strcmp(decision, "yes")==0
    
    % The if-statement would stop the game entirely using built-in function
    % break and prints a message if the user enters "No" or "no"
    if strcmp(decision, "No")||strcmp(decision, "no")
    fprintf("Alright then. Goodbye!\n");
    break
    
    % This program would ask for another input from the user and prints a message if the user enters an answer other than "No"
    else
    fprintf("Please follow the instructions! Try again!!\n");
    decision=input("Do you want to play a game? Please enter Yes or No only : ","s");
    
    end
    
end   


