
% Prints a message to inform the user the game has begun
    fprintf("\nLet's play the game!\n");
    
    % The location of the treasure 
    % This program generates random integers between 1 and 10 for variables in
    % the location, which are X and Y
    X=randi([1,10]);
    Y=randi([1,10]);
    
    % This program stores the integers of X and Y into a vector named "Location"
    Location=[X,Y];
    
    % This program allows the user to input a guess of the location of the treasure
    % It only allows numbers that are between 1 and 10 (inclusive)
    n=input("Please enter a number between 1 and 10: ");
    m=input("Please enter another number between 1 and 10: ");
    
    for i=1:20
    Remaining_turns=20
    if Remaining_turns-i==0
        fprintf("Game over! You lose")
        fprintf("The location is at ");
        disp(Location);
    else
        i=i+1
        fprintf("You still have %d turns left.\n", Remaining_turns-i);
    end
    end

    % This while loop displays the message based on the distance between the user's number and the correct answers and reads in the numbers iteratively until the user gets the correct numbers
    while n~=X || m~=Y
        
        % Stores the user's numbers into a vector named "User"
        User=[n,m];
        
        % Displays the error message if the numbers are less than 1 or more than 10
        if n<1||n>10||m<1||m>10 
            fprintf("Invalid! Try again!\n\n");
            
        % Displays the error message if the numbers are less than 1 and more than 10
        elseif n<1||n>10&&m<1||m>10 
            fprintf("Invalid! Try again!\n\n");
            
        % Displays the location of the user and a message that informs the user that they are very close to the location of the treasure
        elseif abs(n-X)==0 && abs(m-Y)==1 || abs(m-Y)==0 && abs(n-X)==1
            fprintf("Your current location is :");
            disp(User);
            fprintf("You're almost there!\n\n");
            
        % Displays the location of the user and a message that informs the user that they are close to the location of the treasure
        elseif abs(n-X)<=2 && abs(m-Y)<=2
            fprintf("Your current location is :");
            disp(User);
            fprintf("You�re getting closer...\n\n");
            
        % Displays the location of the user and a message that informs the user that they are far from the location of the treasure        
        else
            fprintf("Your current location is :");
            disp(User);
            fprintf("You�re getting further away...\n\n");
        
        end
        
        % This program asks for the number from the user again if the required number is not achieved in the previous turn
        n=input("Please enter a number between 1 and 10: ");
        m=input("Please enter another number between 1 and 10: ");
        
    end
    
    % Display the message "Congratulations! You found it!" when the user inputs the integers that is identical to the generated location of the treasure
    fprintf("\nCongratulations! You found it!\nHere's the prize!\nGoodbye!\nHave fun with the blast!\n");
    
    % This program loads the image which is copied directly from an online search engine
    imageData=imread('TreasureBoxImage.jpeg');
    
    % Display the .jpeg file in MATLAB as an image
    imshow(imageData);