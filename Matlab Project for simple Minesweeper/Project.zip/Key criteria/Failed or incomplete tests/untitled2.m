if 
    while 
        for 
            count=0;
while count<=1 && count>=10
    fprintf("Loop count: %d\n", count)
    count=count+1
end
for loop
    while loop
        if loop
            input