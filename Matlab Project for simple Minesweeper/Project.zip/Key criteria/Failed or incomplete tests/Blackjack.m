% A game of 21
% Input username 
% While loop when enter username 
% Generates a card number randi(1:10)
% if n>21 fprintf "You lose!"
% else fprintf("Enter number: ")
% For 5 times
% input image 
% For 5 times 
% 

Card=randi([1,10],1)

% A game of 21
Computer=randi(1:10);

for i =1:5
    
end


