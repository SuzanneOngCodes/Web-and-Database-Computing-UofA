% This program covers the key MATLAB programming concepts required by this assignment (I/O, Loops, Vectors/2D Arrays, and Conditional Execution)
% This is a game where the user tries to guess a number 2D location in an imaginary grid based on feedback from the the computer in terms of information like �you�re getting closer� or �you�re far, far away from the treasure�.
% If the user won, the program would stop requesting the numbers from the user, prints out the winning message and displays an image as a prize

clc
clear all
close all

% Reads the username
name=input("Please enter your name: ","s");
fprintf("Hi %s\n", name);

% Asks the user whether or not they want to play this game
decision=input("Do you want to play a game? Please enter Yes or No only : ","s");

% This while loop compares the answer entered by the user with the variable "decision"
% It will start the game when the user entered "Yes", stop the game if the user entered "No" and demands another input if the user did not follow the instructions to enter 'Yes' or 'No' only
while strcmp(decision, "Yes")==0 && strcmp(decision, "yes")==0
    
    % The if-statement would stop the game entirely using built-in function
    % break and prints a message if the user enters "No" or "no"
    if strcmp(decision, "No")||strcmp(decision, "no")
    fprintf("Alright then goodbye!\n");
    break
    
    % This program would ask for another input from the user and prints a message if the user enters an answer other than "No"
    else
    fprintf("Please follow the instructions! Try again!!\n");
    decision=input("Do you want to play a game? Please enter Yes or No only : ","s");
    
    end
    
end   

% Start the game if the user answered "Yes"
if strcmp(decision, "Yes")~=0 || strcmp(decision, "yes")~=0 
    
    % Prints a message to inform the user the game has begun
    fprintf("\nLet's play the game!\n");
    
    % The location of the treasure 
    % This program generates random integers between 1 and 10 for variables in
    % the location, which are X and Y
    X=randi([1,10]);
    Y=randi([1,10]);
    
    % This program stores the integers of X and Y into a vector named "Location"
    Location=[X,Y];
    
    % This program allows the user to input a guess of the location of the treasure
    % It only allows numbers that are between 1 and 10 (inclusive)
    n=input("Please enter a number between 1 and 10: ");
    m=input("Please enter another number between 1 and 10: ");
    
    % This while loop displays the message based on the distance between the user's number and the correct answers and reads in the numbers iteratively until the user gets the correct numbers
    while n~=X || m~=Y
        
        % Stores the user's numbers into a vector named "User"
        User=[n,m];
        
        % Displays the error message if the numbers are less than 1 or more than 10
        if n<1||n>10||m<1||m>10 
            fprintf("Invalid! Try again!\n\n");
            
        % Displays the error message if the numbers are less than 1 and more than 10
        elseif n<1||n>10&&m<1||m>10 
            fprintf("Invalid! Try again!\n\n");
            
        % Displays the location of the user and a message that informs the user that they are very close to the location of the treasure
        elseif abs(n-X)==0 && abs(m-Y)==1 || abs(m-Y)==0 && abs(n-X)==1
            fprintf("Your current location is :");
            disp(User);
            fprintf("You're almost there!\n\n");
            
        % Displays the location of the user and a message that informs the user that they are close to the location of the treasure
        elseif abs(n-X)<=2 && abs(m-Y)<=2
            fprintf("Your current location is :");
            disp(User);
            fprintf("You�re getting closer...\n\n");
            
        % Displays the location of the user and a message that informs the user that they are far from the location of the treasure        
        else
            fprintf("Your current location is :");
            disp(User);
            fprintf("You�re far, far away from the treasure...\n\n");
        
        end
        
        % This program asks for the number from the user again if the required number is not achieved in the previous turn
        n=input("Please enter a number between 1 and 10: ");
        m=input("Please enter another number between 1 and 10: ");
        
    end
    
    % Display the message "Congratulations! You found it!" when the user inputs the integers that is identical to the generated location of the treasure
    fprintf("\nCongratulations! You found it!\nHere's the prize!\nGoodbye!\nHave fun with the blast!\n");
    
    % This program loads the image which is copied directly from an online search engine
    imageData=imread('TreasureBoxImage.jpeg');
    
    % Display the .jpeg file in MATLAB as an image
    imshow(imageData);
    
end

