clc

% Allow user to input the level of difficulty in the form of a string such
% as 'Easy', 'Hard' and 'Depressing'
difficulty=input("",'s');

% In function Treasure
d=difficulty;


% This while loop displays the 'invalid' message if the user fails to input
% the correct response for the difficulty of the game and reads in another
% string iteratively until the user enters the correct response based on
% the instructions given
while strcmp(d, "Easy")==0 && strcmp(d, "easy")==0 && strcmp(d, "Hard")==0 && strcmp(d, "hard")==0 && strcmp(d, "Depressing")==0 && strcmp(d, "depressing")==0 
    
    % Prints the message
    fprintf("Invalid! Please try again\n");
    fprintf("Choose your difficulty\n");
    
    % Read the input the user entered
    d=input("Easy, Hard , or Depressing?: ","s");
    
end