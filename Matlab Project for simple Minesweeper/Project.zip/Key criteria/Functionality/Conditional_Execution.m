% Functionality 4 - Conditional execution

clc

% Example 
% If-statement is used to produce the desired output if the conditions are
% met based on the numbers from the user's input

if n<1||n>10||m<1||m>10 
    fprintf("Invalid! Try again!\n\n");
        
elseif n<1||n>10&&m<1||m>10 
    fprintf("Invalid! Try again!\n\n");
        
elseif abs(n-X)==0 && abs(m-Y)==1 || abs(m-Y)==0 && abs(n-X)==1
    fprintf("Your current location is :");
    disp(User);
    fprintf("You're almost there!\n\n");
        
elseif abs(n-X)<=2 && abs(m-Y)<=2
    fprintf("Your current location is :");
    disp(User);
    fprintf("You�re getting closer...\n\n");

else 
    fprintf("Your current location is :");
    disp(User);
    fprintf("You�re far, far away from the treasure...\n\n");
        
end