% An example of while loop that is used in the program that projects an
% output based on the user's response

% This program allows the user to input a guess of the location of the
% treasure
n=input("Please enter a number between 1 and 10: ");
m=input("Please enter another number between 1 and 10: ");

% This while loop displays the message based on the distance between the user's number and the correct answers and reads in the numbers iteratively until the user gets the correct numbers
while n~=X || m~=Y
    User=[n,m];
    if n<1||n>10||m<1||m>10 
        fprintf("Invalid! Try again!\n\n");
        
    elseif n<1||n>10&&m<1||m>10 
        fprintf("Invalid! Try again!\n\n");
        
    elseif abs(n-X)==0 && abs(m-Y)==1 || abs(m-Y)==0 && abs(n-X)==1
        fprintf("Your current location is :");
        disp(User);
        fprintf("You're almost there!\n\n");
        
    elseif abs(n-X)<=2 && abs(m-Y)<=2
        fprintf("Your current location is :");
        disp(User);
        fprintf("You�re getting closer...\n\n");

    else 
        fprintf("Your current location is :");
        disp(User);
        fprintf("You�re getting further away...\n\n");
        
    end
    
    % This program asks for the number continuously from the user if the required number
    % is not achieved
    n=input("Please enter a number between 1 and 10: ");
    m=input("Please enter another number between 1 and 10: ");
    
end