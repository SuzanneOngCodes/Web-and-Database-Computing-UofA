% Functionality 6 - Visualisation of data based on the numbers entered by the user

clc
close all

% This program allows the user to input a guess of the location of the treasure
n=input("Please enter a number: ");
m=input("Please enter another number: ");

% Displays the plots on the same window
hold on;

% Displays the user's input into red dot'*' plots (as shown in the book "Introduction to MATLAB Programming pages 95 and 98")
plot(n,m,'r*');

n=input("Please enter a number: ");
m=input("Please enter another number: ");

% Displays the user's input into green 'x' plots
plot(n,m,'gx');

n=input("Please enter a number: ");
m=input("Please enter another number: ");

% Displays the user's input into blue 'x' plots
plot(n,m,'bs');
