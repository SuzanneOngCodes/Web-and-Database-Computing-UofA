% Functionality 3 - Vector

% Example 1 
% This program allows the user to input a guess of the location of the
% treasure
n=input("Please enter a number between 1 and 10: ");
m=input("Please enter another number between 1 and 10: ");

% Stores the user's numbers into a vector named "User"
User=[n,m];
disp(User)

clc

% Randomisation of data in a vector

% This program generates random integers between 1 and 5 for variables in
% the location of the treasure for the Easy difficulty, which are X and Y
X=randi([1,5]);
Y=randi([1,5]);

Location=[X,Y];

% This program generates random integers between 1 and 10 for variables in the location of the treasure for the Hard difficulty, which are X and Y
X=randi([1,10]);
Y=randi([1,10]);

Location=[X,Y];

% This program generates random integers between 1 and 15 for variables in the location of the treasure for the Depressing difficulty, which are X and Y
X=randi([1,15]);
Y=randi([1,15]);

Location=[X,Y];
