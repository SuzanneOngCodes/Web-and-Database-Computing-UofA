% Functionality 1 
% Examples of the program reading an input and displays the required output

% Example 1
% Reads the username
name=input("Please enter your name: ","s");
fprintf("Hi %s\n", name);

% Example 2
% This program allows the user to input a guess of the location of the treasure
n=input("Please enter a number between 1 and 10: ");
m=input("Please enter another number between 1 and 10: ");